#include <iostream>
#include <stdio.h>
#include <string.h>
const int mod=1000000007;
const int biao=1000000;
int main()
#define int long long
{
	freopen("boss.in","r",stdin);
	freopen("boss.arr","w",stdout);
	int n;
	scanf("%lld",&n);
	while(n--)
	{
		int now,ans=0;
		scanf("%lld",&now);
		now%=mod;
		for(int a=1;a<=now;a++){
			ans+=((a+1)*a)>>1;
			ans%=mod;
			if(!(a%1000000))
				printf("%lld,",ans);
		}
		printf("%lld\n",ans);
	}
}