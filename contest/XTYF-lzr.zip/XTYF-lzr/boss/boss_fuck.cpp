#include <iostream>
#include <stdio.h>
#include <string.h>

const int mod=1000000007;
int main() {
	freopen("boss.in","r",stdin);
	// freopen("boss.out","w",stdout);
	int n; scanf("%d",&n);
	while(n--){
	// while(1){
		long long now;long long ans=0;
		scanf("%lld",&now);
		now%=mod;
		ans+=((((1+now)%mod)*(now%mod))%mod)>>1;
		switch(now%3)
		{
			case 0:
			{
				switch(now&1)
				{
					case 1:
						ans+=(((2*now+1)%mod)*(((now+1)>>1)%mod)%mod)*((now/3)%mod);
						break;
					case 0:
						ans+=(((2*now+1)%mod)*((now+1)%mod)%mod)*((now/6)%mod);
						break;
				}
				break;
			}
			case 1:
			{
				switch(now&1)
				{
					case 1:
						ans+=((((2*now+1)/3)%mod)*(((now+1)>>1)%mod)%mod)*(now%mod);
						break;
					case 0:
						ans+=((((2*now+1)/3)%mod)*((now+1)%mod)%mod)*((now>>1)%mod);
						break;
				}
				break;
			}
			case 2:
			{
				switch(now&1)
				{
					case 1:
						ans+=(((2*now+1)%mod)*(((now+1)/6)%mod)%mod)*(now%mod);
						break;
					case 0: 
						ans+=(((2*now+1)%mod)*(((now+1)/3)%mod)%mod)*((now>>1)%mod);
						break;
				}
			}
		}
		printf("%lld\n",((ans%mod)>>1)%mod
		);
	}
}