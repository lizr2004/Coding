def fuck(a):
	return ((((2*a+1)/3))*(((a+1)>>1)))*(a)

print(fuck(9704029)%1000000007)