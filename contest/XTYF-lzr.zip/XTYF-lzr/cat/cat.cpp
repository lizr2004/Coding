#include <iostream>
#include <stdio.h>
#include <string.h>
int x[102400],ans;
inline int read(int &in) {
	in=0;char c=getchar(),cheng=1;
	while(c<'0' || c>'9'){if(c=='-')cheng=-1;c=getchar();}
	while(c>='0' && c<='9'){in=in*10+c-'0';c=getchar();}
	return in*=cheng;
}

int main() {
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	int n;
	read(n);
	for(int a=1;a<=n;a++)read(x[a]);

	for(int a=1;a<=n;a++){
	for(int b=a;b<=n;b++){if(x[a]<x[b])
	for(int c=b;c<=n;c++){if(x[c]<x[b])
	for(int d=c;d<=n;d++){
	for(int e=d;e<=n;e++){if(x[d]<x[e])
	for(int f=e;f<=n;f++)if(x[f]<x[e])
		ans++;
	}
	}
	}
	}
	}
	printf("%d\n",ans);
}
